
import random

def gen_vol( numpoints, totalvol ):
    rlist = []
    for jj in range(0,num):
        r = 0
        for kk in range(0,3):
            r += random.random()
        rlist.append(r/3.0)
    rlist
    s = sum(rlist)
    vol = []
    for r in rlist:
        vol.append((r/s)*tot)



11/5/2019,3080.8,3083.95,3072.15,3074.62,585634570
5 11/6/2019,3075.1,3078.34,3065.89,3076.78,544288522
6 11/7/2019,3087.02,3097.77,3080.23,3085.18,566117910
7 11/8/2019,3081.25,3093.09,3073.58,3093.08,460757054

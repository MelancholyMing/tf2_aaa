---
name: Feedback
about: What do you think of mplfinance?  Pros? Cons?  Thoughts?
title: 'Comment:'
labels: 'feedback'
assignees: ''

---

What do you think of mplfinance?  Pros? Cons?  Thoughts?
Thank you for taking the time to provide feedback.  Much appreciated!
